package com.example.project.demoProject.controller;
import org.springframework.web.bind.annotation.*;

@RequestMapping("/user")//http://localhost:8080/user
@RestController
public class usercontroller {
    @GetMapping
    public String getUser(){
        return "get User Id";
    }
    @PostMapping
    public  String creteUser(){
        return "create User id";
    }
    @PutMapping
    public String uppdateUser(){
        return "uppdate User id";
    }
    @DeleteMapping
    public String deleteUser(){
        return "delete User Id";
    }
}
